// Create a MathOperations class with overloaded multiply() methods:
//One method should accept two integers and return their product.
//Another method should accept three integers and return their product.
//Write a program to demonstrate each overloaded method, and try to understand why overloading works here.
package com.demo4;

public class MathOperations {


    int a;
    int b;


   int multiplay(int a,int b){
        return a*b;
       }

    int multiplay(int a,int b,int c){
        return a*b*c;

 }

    public static void main(String[] args) {

        MathOperations obj=new MathOperations();
       int result1= obj.multiplay(10,20);
        System.out.println(result1);
        int result2=obj.multiplay(2,6,10);
        System.out.println(result2);


    }

}
