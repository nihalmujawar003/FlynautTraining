//~ Create a Person class with basic details like name and age. Then, create two subclasses:
// Student and Teacher. Both should inherit from Person and add specific attributes
// (e.g., grade for Student and subject for Teacher).
// Write a program to display details of a Student and a Teacher, showing inheritance in action.


package com.demo3;

public class Person {

    String name;
    int age;

    void setPersonDetails(String name, int age){
        this.name=name;
        this.age=age;

    }
    void displayPersonDetails(){
        System.out.println("Name :"+name);
        System.out.println("age :"+age);
    }


}
