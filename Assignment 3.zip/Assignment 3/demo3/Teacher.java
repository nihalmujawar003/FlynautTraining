package com.demo3;

public class Teacher extends Person{

    int empID;
    String subject;

    void setTeacherDetails(String name,int age,int empID,String subject){
        setPersonDetails(name,age);

        this.empID=empID;
        this.subject=subject;
    }
    void displayTeacherDetail(){
        displayPersonDetails();
        System.out.println("EmpId :"+empID);
        System.out.println("Subject :"+subject);
    }

}
