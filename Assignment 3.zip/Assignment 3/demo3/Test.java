package com.demo3;

public class Test {

    public static void main(String[] args) {

     Student student=new Student();
     student.setStudentDetails("Nihal",26,18,'A');
        System.out.println("-------Student Details---------");
        student.displayStudentDetails();



        Teacher teacher=new Teacher();
        teacher.setTeacherDetails("Ashish",45,456,"Math");
        System.out.println("\n--------Teacher Details-----------");
        teacher.displayTeacherDetail();





    }

}
