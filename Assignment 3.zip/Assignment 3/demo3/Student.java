package com.demo3;

public class Student extends Person{

    int rollNo;
    char grade;


    void setStudentDetails(String name,int age,int rollNo,char grade){
        setPersonDetails(name,age);
        this.rollNo=rollNo;
        this.grade=grade;
    }


     void displayStudentDetails(){
        displayPersonDetails();
         System.out.println("RollNo :"+rollNo);
         System.out.println("Grade :"+grade);
     }

}
