package com.demo8;

public class UPIPayment extends Payment{

    @Override
    void pay() {

        System.out.println("Processing UPI Payment");
    }
}
