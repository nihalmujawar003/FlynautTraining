//Consider an e-commerce application with a class Payment. Create subclasses CreditCardPayment,
// DebitCardPayment, and UPIPayment that each override a pay() method.
// Demonstrate polymorphism by using a single reference of type Payment to invoke pay() for different payment types

package com.demo8;

public class Payment {


    void pay(){
        System.out.println("Processing Generic Payment");
    }





}
