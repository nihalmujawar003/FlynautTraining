package com.demo8;

public class DebitCardPayment extends Payment {

    @Override
    void pay() {

        System.out.println("Processing DebitCard Payment");
    }
}
