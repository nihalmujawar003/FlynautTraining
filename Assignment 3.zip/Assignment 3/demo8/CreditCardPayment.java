package com.demo8;

public class CreditCardPayment extends Payment{
    @Override
    void pay() {

        System.out.println("Processing CreditCard Payment");
    }
}
