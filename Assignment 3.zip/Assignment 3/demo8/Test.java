package com.demo8;

public class Test {


    public static void main(String[] args) {

  Payment payment; // Super Class Reference

  payment=new Payment();
  payment.pay();

  payment=new CreditCardPayment();
  payment.pay();

  payment=new DebitCardPayment();
  payment.pay();

  payment=new UPIPayment();

  payment.pay();







    }
}
