//Create a Person class with a method getDetails() that prints "Person details."
// Create a Student class that inherits from Person and overrides getDetails() to add
// "Student details." Use super to call the Person class’s getDetails() method from within the
// Student class’s getDetails() method,and display both details.
package com.demo6;

public class Person {

    void getDetails(){

        System.out.println("Person Details");
    }


}
