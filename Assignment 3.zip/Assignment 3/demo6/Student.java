package com.demo6;

public class Student extends Person {


    @Override
    void getDetails() {
        super.getDetails();
        System.out.println("Student Details");
    }
}
