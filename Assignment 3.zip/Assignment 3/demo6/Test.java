package com.demo6;

public class Test {

    public static void main(String[] args) {

        Student student=new Student();
        student.getDetails();


    }
}
