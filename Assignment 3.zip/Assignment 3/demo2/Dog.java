package com.demo2;

public class Dog extends Mammal{

    @Override
    public void sound() {
        super.sound();
    }

    void showDetails(){
        hasFur(); // Access Mammal class method

        sound();  // Acess Animal Class method

    }
}
