package com.demo2;

public class Test {


    public static void main(String[] args) {
        Dog dog=new Dog();

        dog.showDetails();







    }
}
