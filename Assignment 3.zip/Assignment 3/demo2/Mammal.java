package com.demo2;

public class Mammal extends Animal{

    void hasFur(){
        System.out.println("Mammal Has Fur");
    }


}
