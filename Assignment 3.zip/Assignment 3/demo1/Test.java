package com.demo1;

public class Test {

    public static void main(String[] args) {
        Car car=new Car();

        System.out.println(car.speed);
        System.out.println(car.brand);
        System.out.println(car.model);
        car.displayInfo();


    }
}
