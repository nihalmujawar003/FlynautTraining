
package com.demo1;

public class Car extends Vehicle{
    String brand="Mahindra";
    String model="Bolero";




}
