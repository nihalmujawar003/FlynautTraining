// Create a Vehicle class with properties like speed and a method displayInfo() to show speed.
// Create a Car class that inherits from Vehicle and adds properties like brand and model.
// Write a program to display the details of the Car using the displayInfo() method.
package com.demo1;

public class Vehicle {

    int speed;

    public void displayInfo(){
        System.out.println(speed);

    }



}
