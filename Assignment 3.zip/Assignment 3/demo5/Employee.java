// Develop a class Employee with a method work(), which prints "Employee is working."
// Create a subclass Manager that overrides work() to print "Manager is managing the team."
// Demonstrate method overriding by creating objects of Employee and Manager and calling the work() method on each.
package com.demo5;

public class Employee {

    void work(){
        System.out.println("Employee is Working ");
    }
}
