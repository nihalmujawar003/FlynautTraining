package com.demo5;

public class Manager extends Employee {

    @Override
    void work() {


        System.out.println("Manager Managing the team");
    }
}
