package com.demo5;

public class Test {


    public static void main(String[] args) {
        Employee emp=new Employee();

        emp.work();   // call employee class work method

        Manager mang=new Manager();
         mang.work();  // call Manger class Work Method
    }

}
