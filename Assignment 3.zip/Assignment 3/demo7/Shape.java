//Create a class Shape with an overloaded calculateArea() method (one for circle, one for rectangle)
// and a subclass Triangle that overrides calculateArea() to handle triangles.
// Demonstrate the difference between overloading and overriding with examples.
package com.demo7;

public class Shape {


    public void calculateArea(double radius) {
        double area = Math.PI * radius * radius;
        System.out.println("Area of Circle: " + area);
    }

    // Overloaded method for rectangle
    public void calculateArea(double length, double width) {
        double area = length * width;
        System.out.println("Area of Rectangle: " + area);
    }

    // Method meant to be overridden
    public void calculateArea() {
        System.out.println("Generic Shape Area");
    }

}
