package com.demo7;

public class Test {


    public static void main(String[] args) {
        Shape shape = new Shape();

        // Method Overloading
        shape.calculateArea(7);           // Circle
        shape.calculateArea(5, 10);       // Rectangle

        // Method Overriding
        Triangle triangle = new Triangle(4, 6);
        triangle.calculateArea();
    }
}
